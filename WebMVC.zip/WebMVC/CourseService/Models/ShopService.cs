﻿using CourseService.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseService.Models
{
    public class ShopService : IShopService
    {
        private readonly IMemberCourseScheduleRepository _memberCourseScheduleRepository;
        public ShopService(IMemberCourseScheduleRepository memberCourseScheduleRepository)
        {
            _memberCourseScheduleRepository = memberCourseScheduleRepository;
        }
        public async Task<bool> AddShopOrderAsync(Guid memberId, Guid courseScheduleId)
        {
            //判斷是否已經購買過
            var result = await _memberCourseScheduleRepository.IsExistMemberCourseScheduleAsync(memberId, courseScheduleId);
            if (result)
            {
                return false;
            }

            return await _memberCourseScheduleRepository.AddMemberCourseScheduleAsync(memberId, courseScheduleId);

        }

        public async Task<bool> DelShopOrderAsync(Guid scheduleId)
        {
            return await _memberCourseScheduleRepository.DelMemberCourseScheduleAsync(scheduleId);
        }

        public async Task<IEnumerable<ShopOrderModel>> GetShopOrderListAsync(Guid memberId)
        {
            return await _memberCourseScheduleRepository.QueryMemberCourseScheduleAsync(memberId);
        }
    }
}
