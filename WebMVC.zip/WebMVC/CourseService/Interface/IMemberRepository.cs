﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourseService.Models;

namespace CourseService.Interface
{
    public interface IMemberRepository
    {
        Task<bool> CreateAsync(MemberModel member);

        Task<MemberModel> QueryByEmailAsync(string email);
        Task<MemberModel> QueryByIdAsync(Guid id);

        Task<bool> UpdatePwdAsync(Guid id, string pwd);

        Task<bool> UpdateInfoAsync(UserInfoReqModel userInfoReqModel);
    }
}
