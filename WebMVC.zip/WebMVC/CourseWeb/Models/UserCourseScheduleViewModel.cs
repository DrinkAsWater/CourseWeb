﻿namespace CourseWeb.Models
{
    public class UserCourseScheduleViewModel
    {
        public Guid Id { get; set; }
        public string CourseName { get; set; }
        public string TeacherName { get; set; }
        public string CourseDate { get; set; }
    }
}
