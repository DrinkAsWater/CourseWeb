﻿using CourseData.Models;
using CourseService.Interface;
using CourseService.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseData.Repo
{
    public class MemberRepository : IMemberRepository
    {
        private readonly KhNetCourseContext _dbContext;
        public MemberRepository(KhNetCourseContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<bool> CreateAsync(MemberModel member)
        {
            await _dbContext.Students.AddAsync(new Student()
            {
                Id = member.Id,
                Name = member.UserName,
                Email = member.Email,
                Password = member.Pwd
            });

            await _dbContext.SaveChangesAsync();

            return true;
        }

        public async Task<MemberModel> QueryByEmailAsync(string email)
        {
            MemberModel memberModel = null;

            var student = await _dbContext.Students.FirstOrDefaultAsync(s => s.Email == email);
            if (student != null)
            {
                memberModel = new MemberModel()
                {
                    Id = student.Id,
                    UserName = student.Name,
                    Email = student.Email,
                    Pwd = student.Password
                };
            }
            return memberModel;
        }

        public async Task<MemberModel> QueryByIdAsync(Guid id)
        {
            MemberModel memberModel = null;

            var student = await _dbContext.Students.FirstOrDefaultAsync(s => s.Id == id);
            if (student != null)
            {
                memberModel = new MemberModel()
                {
                    Id = student.Id,
                    UserName = student.Name,
                    Email = student.Email,
                    Pwd = student.Password,
                    Mobile = student.Mobile
                };
            }
            return memberModel;
        }

        public async Task<bool> UpdateInfoAsync(MemberInfoReqModel userInfoReqModel)
        {
            var stu = await _dbContext.Students.FirstOrDefaultAsync(x => x.Id == userInfoReqModel.UserId);
            if (stu == null)
            {
                return false;
            }

            stu.Name = userInfoReqModel.Name;
            stu.Mobile = userInfoReqModel.Mobile;

            await _dbContext.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UpdatePwdAsync(Guid id, string pwd)
        {
            var stu = await _dbContext.Students.FirstOrDefaultAsync(x => x.Id == id);
            if (stu == null)
            {
                return false;
            }

            stu.Password = pwd;

            await _dbContext.SaveChangesAsync();
            return true;
        }
    }
}
