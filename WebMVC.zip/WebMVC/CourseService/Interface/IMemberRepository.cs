﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourseService.Models;

namespace CourseService.Interface
{
    public interface IMemberRepository
    {
        Task<bool> CreateAsync(MemberModel member);
    }
}
