﻿using CourseData.Models;
using CourseData.Repo;
using CourseService.Interface;
using CourseService.Models;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;

namespace CourseWeb
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddDbContext<KhNetCourseContext>(
                options => options.UseSqlServer(builder.Configuration.GetConnectionString("KhNetCourseDB"))
                );

            // Cookie Authentication
            builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
               .AddCookie(CookieAuthenticationDefaults.AuthenticationScheme, config =>
               {
                   config.Cookie.Name = "UserLoginCookie"; // Cookie 名稱
                   config.LoginPath = "/Member/Login"; // 未登入時導向的登入頁面
               });

            // Add services to the container.
            builder.Services.AddControllersWithViews();

            builder.Services.AddScoped<ICourseScheduleService, CourseScheduleService>();
            builder.Services.AddScoped<ICourseScheduleRepository, CourseScheduleRepository>();
            builder.Services.AddScoped<IMemberRepository, MemberRepository>();
            builder.Services.AddScoped<IMemberService, MemberService>();
            builder.Services.AddScoped<IMemberCourseScheduleRepository, MemberCourseScheduleRepository>();
            builder.Services.AddScoped<IShopService, ShopService>();

            // 註冊 HttpClient 服務
            builder.Services.AddHttpClient();


            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthentication(); // 啟用身份驗證中介軟體
            app.UseAuthorization(); // 啟用授權中介軟體

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");

            app.Run();
        }
    }
}
