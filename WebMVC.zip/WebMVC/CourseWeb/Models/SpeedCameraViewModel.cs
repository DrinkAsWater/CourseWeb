using System.Text.Json.Serialization;

namespace CourseWeb.Models
{
    /// <summary>
    /// 台南市固定式測速照相地點資料
    /// </summary>
    public class SpeedCameraViewModel
    {
        /// <summary>
        /// 轄區分局
        /// </summary>
        [JsonPropertyName("轄區分局")]
        public string District { get; set; }

        /// <summary>
        /// 行政區
        /// </summary>
        [JsonPropertyName("行政區")]
        public string Area { get; set; }

        /// <summary>
        /// 設置位置
        /// </summary>
        [JsonPropertyName("設置位置")]
        public string Location { get; set; }

        /// <summary>
        /// 拍攝行向
        /// </summary>
        [JsonPropertyName("拍攝行向")]
        public string Direction { get; set; }

        /// <summary>
        /// 速限
        /// </summary>
        [JsonPropertyName("速限")]
        public string SpeedLimit { get; set; }
    }
}
