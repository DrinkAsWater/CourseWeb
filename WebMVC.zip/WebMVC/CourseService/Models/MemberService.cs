﻿using CourseService.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseService.Models
{
    public class MemberService : IMemberService
    {
        private readonly IMemberRepository _memberRepository;
        public MemberService(IMemberRepository memberRepository)
        {
            _memberRepository = memberRepository;
        }

        public async Task<bool> MemberInfoUpdateAsync(MemberInfoReqModel memberInfoReqModel)
        {
            await _memberRepository.UpdateInfoAsync(memberInfoReqModel);
            return true;
        }

        public async Task<bool> MemberPwdUpdateAsync(MemberPwdReqModel memberPwdReqModel)
        {
            //1.檢查帳號是否存在
            var memberInDb = await _memberRepository.QueryByIdAsync(memberPwdReqModel.UserId);
            if (memberInDb == null) return false;

            //2.驗證舊密碼
            var oldHashPwd = PwdHelper.PwdSHA256Hash(memberPwdReqModel.OldPwd, memberInDb.Id.ToString());
            if (oldHashPwd != memberInDb.Pwd) return false;

            //3.更新新密碼
            var newHashPwd = PwdHelper.PwdSHA256Hash(memberPwdReqModel.NewPwd, memberInDb.Id.ToString());
            return await _memberRepository.UpdatePwdAsync(memberPwdReqModel.UserId, newHashPwd);
        }

        public async Task<bool> MemberRegisterAsync(MemberModel member)
        {
            //1.驗證重覆註冊(email重覆)
            var memberInDb = await _memberRepository.QueryByEmailAsync(member.Email);
            if (memberInDb != null) return false;

            //2.密碼hash
            member.Id = Guid.NewGuid();
            member.Pwd = PwdHelper.PwdSHA256Hash(member.Pwd, member.Id.ToString());

            //3.寫入資料庫
            return await _memberRepository.CreateAsync(member);
        }

        public async Task<MemberModel> MemberSignAsync(string email, string pwd)
        {
            //1.檢查帳號是否存在
            var memberInDb = await _memberRepository.QueryByEmailAsync(email);
            if (memberInDb == null) return null;

            //2.檢查密碼是否正確
            var hashPwd = PwdHelper.PwdSHA256Hash(pwd, memberInDb.Id.ToString());
            if (hashPwd != memberInDb.Pwd) return null;

            return memberInDb;
        }

        public async Task<MemberModel> QueryMemberAsync(Guid memberId)
        {
            return await _memberRepository.QueryByIdAsync(memberId);
        }
    }
}
