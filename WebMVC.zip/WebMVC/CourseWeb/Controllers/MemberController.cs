﻿using CourseService.Interface;
using CourseService.Models;
using CourseWeb.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace CourseWeb.Controllers
{
    public class MemberController : Controller
    {
        private readonly IMemberService _memberService;
        public MemberController(IMemberService memberService)
        {
            _memberService = memberService;
        }


        [HttpGet]
        public IActionResult UserRegister()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UserRegister(UserRegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                //實作會員註冊邏輯
                var result = await _memberService.MemberRegisterAsync(
                    new MemberModel
                    {
                        UserName = model.Username!,
                        Pwd = model.Password!,
                        Email = model.Email!
                    });

                // 假如註冊成功，重導向到登入頁面
                if (result)
                    return RedirectToAction("Login");

                // 假如註冊失敗，顯示錯誤訊息
                ModelState.AddModelError("system", "註冊失敗，帳號重覆");
            }

            // 如果有錯誤，重新顯示註冊頁面
            return View(model);
        }


        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                //登入
                var member = await _memberService.MemberSignAsync(model.Username, model.Password);

                if (member == null)
                {
                    // 假如登入失敗，顯示錯誤訊息
                    ModelState.AddModelError("system", "帳號或密碼錯誤");
                    return View(model);
                }


                //MVC 登入狀態處理
                //Claim[] 是一個"聲明"陣列，用來儲存使用者的身份資訊
                Claim[] claims = new[] {
                    new Claim(ClaimTypes.Name, member.UserName)
                    , new Claim(ClaimTypes.NameIdentifier, member.Id.ToString())
                };
                //將多個 Claims 組合成一個身份識別物件並指定這是基於 Cookie 的驗證方式
                ClaimsIdentity claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                //ASP.NET Core 中代表已驗證使用者的主要物件,包含使用者的所有身份識別資訊
                ClaimsPrincipal principal = new ClaimsPrincipal(claimsIdentity);

                //執行登入
                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(principal));


                // 假如登入成功，重導向到首頁
                return RedirectToAction("Index", "Home");
            }

            // 如果有錯誤，重新顯示登入頁面
            return View(model);
        }


        [HttpGet]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync();

            return RedirectToAction("Index", "Home");
        }

        [Authorize]
        [HttpGet]
        public IActionResult ChangePwd()
        {
            return View();
        }

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ChangePwd(UserChgPwdViewModel userChgPwdViewModel)
        {
            if (ModelState.IsValid)
            {
                var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier).Value;
                // var currentUserId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                var result = await _memberService.MemberPwdUpdateAsync(
                       new MemberPwdReqModel
                       {
                           UserId = Guid.Parse(currentUserId),
                           OldPwd = userChgPwdViewModel.OldPassword!,
                           NewPwd = userChgPwdViewModel.Password!
                       });

                if (!result)
                {
                    // 假如修改密碼失敗，顯示錯誤訊息
                    ModelState.AddModelError("system", "修改密碼失敗");
                    return View(userChgPwdViewModel);
                }
                // 假如修改密碼成功，強制登出
                return RedirectToAction("Logout");

            }

            return View(userChgPwdViewModel);
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var member = await _memberService.QueryMemberAsync(userId);

            var vm = new UserChgInfoViewModel() { Name = member.UserName, Mobile = member.Mobile };
            return View(vm);
        }

    }
}
