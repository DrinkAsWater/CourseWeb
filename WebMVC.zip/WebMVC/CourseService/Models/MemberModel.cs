﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseService.Models
{
    public class MemberModel
    {
        public Guid Id { get; set; }
        public string UserName { get; set; }
        public string Pwd { get; set; }
        public string Email { get; set; }
        public string? Mobile { get; set; }
    }

    public class MemberPwdReqModel
    {
        public Guid UserId { get; set; }
        public string NewPwd { get; set; }
        public string OldPwd { get; set; }
    }

    public class MemberInfoReqModel
    {
        public Guid UserId { get; set; }
        public string Name { get; set; }
        public string Mobile { get; set; }
    }
}
