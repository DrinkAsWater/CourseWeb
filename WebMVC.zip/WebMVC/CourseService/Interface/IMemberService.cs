﻿using CourseService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseService.Interface
{
    public interface IMemberService
    {
        Task<bool> MemberRegisterAsync(MemberModel member);

        Task<MemberModel> MemberSignAsync(string email, string pwd);

        Task<bool> MemberPwdUpdateAsync(MemberPwdReqModel memberPwdReqModel);

        Task<MemberModel> QueryMemberAsync(Guid memberId);

        Task<bool> MemberInfoUpdateAsync(MemberInfoReqModel memberInfoReqModel);

    }
}
